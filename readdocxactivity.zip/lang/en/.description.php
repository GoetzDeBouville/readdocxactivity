<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['DOCX_READER_NAME'] = '.docx reader';
$MESS['DOCX_READER_DESCRIPTION'] = 'Getting text from .docx files';
