<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['ERROR_NO_LINK'] = 'No file link';

