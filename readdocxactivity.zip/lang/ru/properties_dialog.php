<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['PATH_TO_DOCX_FILE'] = 'Ссылка на файл';