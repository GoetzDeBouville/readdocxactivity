<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['ERROR_NO_LINK'] = 'Не указана ссылка на файл';

