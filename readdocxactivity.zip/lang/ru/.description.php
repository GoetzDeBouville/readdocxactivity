<?php
defined('B_PROLOG_INCLUDED') || die;

$MESS['DOCXREADER_NAME'] = '.docx reader';
$MESS['DOCXREADER_DESCRIPTION'] = 'Получение текста из файлов .docx';
